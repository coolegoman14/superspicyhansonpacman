import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.AbstractAction;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.Timer;


public class StartPacc {

	private JFrame frame = new JFrame("PAC-MAN");
	private JPanel panel;
	Board board = new Board();
	Pacman pacman = new Pacman();
	Blinky blinky = new Blinky();
	Pinky pinky = new Pinky();
	Inky inky = new Inky(blinky);
	Clyde clyde = new Clyde();
	Timers timer;
	Image over;
	Image life;
	BufferedImage lifed;
	int temp = 0;
	static int lives = 3;
	int time = 0;
	static Clip clip;
	static boolean gameOver = false;
	
	public static void playChomp() {
		System.out.println("went to start chomp");
		if(!clip.isActive()) {
			clip.start();
			clip.toString();
		} 
		else {
			System.out.println("clip is active");
		}
	}


	private void drawLives(Graphics g) {
		int x = 800;
		int y =150;
		boolean first = true;
		for(int i = 0; i < lives+1; i++) {
			if(first) {
				g.setFont(new Font("arial", Font.BOLD, 50 ));
				g.drawString("Lives: ", x, y+50);
				first = false;
				x+= 100;
			}else {
				g.drawImage(life, x, y, null);
			}
			
			x += 70;
		}
	}

	public static void stopChomp() {
		clip.stop();
	}

	public static void playEatGhost() {
		stopChomp();
		File chomp = new File("pacman_eatghost.wav");
		try {
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(chomp));

			clip.start();

		} catch (Exception e) {

		}


	}
	public static void playDeath() {
		stopChomp();
		// TODO Auto-generated method stub
		File chomp = new File("pacman_death.wav");
		try {
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(chomp));

			clip.start();

		} catch (Exception e) {

		}

	}

	

	public StartPacc() {
		try {
//			this.over = ImageIO.read(new File("GameOver.png")).getScaledInstance(300, 300, Image.SCALE_SMOOTH);
			this.life=ImageIO.read(getClass().getResource("img/life.png"));
			
			this.over = ImageIO.read(getClass().getResource("img/GameOver.png"));
//			this.victory = ImageIO.read(new File("victory.png")).getScaledInstance(1100,180, Image.SCALE_SMOOTH);
			File chomp = new File("chomp.wav");
			clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(chomp));
		} catch (IOException | LineUnavailableException | UnsupportedAudioFileException e) {
			e.printStackTrace();
		}
	}

//	public static void main(String[] args) {
//		new StartPacc().startGame();
//	}

	public void startGame() {

		panel = new JPanel() {
			@Override
			public void paintComponent(Graphics g) {
				
				super.paintComponent(g);
				
				
				
				board.drawBoard((Graphics2D) g);
				board.drawGhostPath((Graphics2D) g);
				pacman.draw((Graphics2D) g);
				blinky.draw((Graphics2D) g);
				pinky.draw((Graphics2D) g);
				inky.draw((Graphics2D) g);
				clyde.draw((Graphics2D) g);
				drawLives(g);
				
				
				if(gameOver) {
					g.drawImage(over, 200,200, null);
					overTime();
				}
			}
		};
		setUpGame();

		setUpKeyMappings();
		timer.createMovementTimer();
		timer.createScatterTimer();
		timer.createFrightenedTimer(Ghost.scareTime);
	}
	
	
	public void overTime() {
		Timer t = new Timer(1000, null);
		t.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				temp++;
				if(temp == 10) {
					gameOver = false;
					fullReset();
				}
			}
		});
		t.start();
	}

	@SuppressWarnings("serial")
	private void setUpKeyMappings() {

		panel.getInputMap().put(KeyStroke.getKeyStroke("LEFT"), "left");
		panel.getInputMap().put(KeyStroke.getKeyStroke("RIGHT"), "right");
		panel.getInputMap().put(KeyStroke.getKeyStroke("UP"), "up");
		panel.getInputMap().put(KeyStroke.getKeyStroke("DOWN"), "down");

		panel.getActionMap().put("left", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pacman.userDirection = Pacman.Direction.LEFT;
				if (pacman.canMove(Pacman.Direction.LEFT)) {
					Pacman.direction = Pacman.Direction.LEFT;
					pacman.changeAngleAttributes(Pacman.Direction.LEFT);
				}
			}
		});
		panel.getActionMap().put("right", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pacman.userDirection = Pacman.Direction.RIGHT;
				if (pacman.canMove(Pacman.Direction.RIGHT)) {
					Pacman.direction = Pacman.Direction.RIGHT;
					pacman.changeAngleAttributes(Pacman.Direction.RIGHT);
				}

			}
		});
		panel.getActionMap().put("up", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pacman.userDirection = Pacman.Direction.UP;
				if (pacman.canMove(Pacman.Direction.UP)) {
					Pacman.direction = Pacman.Direction.UP;
					pacman.changeAngleAttributes(Pacman.Direction.UP);
				}
			}
		});
		panel.getActionMap().put("down", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pacman.userDirection = Pacman.Direction.DOWN;
				if (pacman.canMove(Pacman.Direction.DOWN)) {
					Pacman.direction = Pacman.Direction.DOWN;
					pacman.changeAngleAttributes(Pacman.Direction.DOWN);
				}
			}
		});
		panel.requestFocusInWindow();
	}

	private void setUpGame() {
		board.makeTileArray();
		timer = new Timers(pacman, panel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(panel);
		panel.setPreferredSize(new Dimension(1500, 800));
		frame.pack();
		frame.setVisible(true);
		panel.setBackground(Color.black);
		this.setUpKeyMappings();
	}
	
	public static void resetGame(){
		Timers.movementTimer.setDelay(50);
		//Board.resetTileArray();
		Pacman.resetPacman();
		Ghost.resetGhosts();
		
	}
	
	public static void fullReset() {
		Timers.movementTimer.setDelay(50);
		Board.resetTileArray();
		Pacman.resetPacman();
		Ghost.resetGhosts();
		lives = 3;
	}

}
