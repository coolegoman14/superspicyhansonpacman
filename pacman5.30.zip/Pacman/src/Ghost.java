import java.awt.Image;

import java.util.ArrayList;
import java.util.List;
public abstract class Ghost {
	
	Image image;
	int speed=6;
	int centerX;
	int centerY;
	List<Tile> openList= new ArrayList<Tile>();
	List<Tile> closedList= new ArrayList<Tile>();
	List<Tile> adjacentTiles= new ArrayList<Tile>();
    List<Tile> finalPath= new ArrayList<Tile>();
	Tile current, targetTile,startTile;
	Tile[][] tileArray;
	
	public Ghost() {
		this.tileArray= Board.cloneTile();
		
	}
	public abstract Tile findTargetTile();
	
public boolean canMove(Tile.Direction desiredDirection,Tile tile){
		if(desiredDirection==Tile.Direction.RIGHT ){
			if(tile.direction==Tile.Direction.LEFT){
				return false;		
			}
			if(tileArray[tile.centerY/Board.TILE_D][(tile.centerX/Board.TILE_D)+1].isWall){
				return false;
			}
			/*else if(Board.tileArray[tile.centerY/Board.TILE_D][tile.centerX/Board.TILE_D].centerX==centerX && Board.tileArray[tile.centerY/Board.TILE_D][(centerX/Board.TILE_D)+1].isWall){
				System.out.println("here");
				return false;
			}*/
		}
		if(desiredDirection==Tile.Direction.LEFT ){
			if(tile.direction==Tile.Direction.RIGHT){
				return false;	
			}
			if(tileArray[tile.centerY/Board.TILE_D][(tile.centerX/Board.TILE_D)-1].isWall){
				return false;
			}
			/*else if(Board.tileArray[tile.centerY/Board.TILE_D][tile.centerX/Board.TILE_D].centerX==centerX && Board.tileArray[tile.centerY/Board.TILE_D][(tile.centerX/Board.TILE_D)-1].isWall){
				return false;
			}*/
		}
		if(desiredDirection==Tile.Direction.UP ){
			if(tile.direction==Tile.Direction.DOWN){
				return false;	
			}
			if(tileArray[(tile.centerY/Board.TILE_D)-1][tile.centerX/Board.TILE_D].isWall){
				return false;
			}
			/*else if(Board.tileArray[tile.centerY/Board.TILE_D][tile.centerX/Board.TILE_D].centerY==centerY && Board.tileArray[(tile.centerY/Board.TILE_D)-1][tile.centerX/Board.TILE_D].isWall){
				return false;
			}*/
		}
		if(desiredDirection==Tile.Direction.DOWN ){
			if(tile.direction==Tile.Direction.UP){
				return false;
				
			}
			if(tileArray[(tile.centerY/Board.TILE_D)+1][tile.centerX/Board.TILE_D].isWall){
				return false;
			}
			/*else if(Board.tileArray[tile.centerY/Board.TILE_D][tile.centerX/Board.TILE_D].centerY==centerY && Board.tileArray[(tile.centerY/Board.TILE_D)+1][tile.centerX/Board.TILE_D].isWall){
				return false;
			}*/
		}
		
		return true;
	}

	public void findAdjacentTiles(Tile current){
		adjacentTiles.clear();
		if(canMove(Tile.Direction.RIGHT,current)){
			tileArray[current.centerY/Board.TILE_D][(current.centerX/Board.TILE_D)+1].direction=Tile.Direction.RIGHT;
			adjacentTiles.add(tileArray[current.centerY/Board.TILE_D][(current.centerX/Board.TILE_D)+1]);
		}
		if(canMove(Tile.Direction.LEFT,current)){
			tileArray[current.centerY/Board.TILE_D][(current.centerX/Board.TILE_D)-1].direction=Tile.Direction.LEFT;
			adjacentTiles.add(tileArray[current.centerY/Board.TILE_D][(current.centerX/Board.TILE_D)-1]);
		}
		if(canMove(Tile.Direction.UP,current)){
			tileArray[(current.centerY/Board.TILE_D)-1][current.centerX/Board.TILE_D].direction=Tile.Direction.UP;
			adjacentTiles.add(tileArray[(current.centerY/Board.TILE_D)-1][current.centerX/Board.TILE_D]);
		}
		if(canMove(Tile.Direction.DOWN,current)){
			tileArray[(current.centerY/Board.TILE_D)+1][current.centerX/Board.TILE_D].direction=Tile.Direction.DOWN;
			adjacentTiles.add(tileArray[(current.centerY/Board.TILE_D)+1][current.centerX/Board.TILE_D]);
		}
	}
	public void findPath(){
		startTile=tileArray[centerY/Board.TILE_D][centerX/Board.TILE_D];
		targetTile= findTargetTile();
		openList.add(startTile);

		while(!openList.isEmpty()){
			 current=findSmallestNode();
			openList.remove(current);
			closedList.add(current);
				if(closedList.contains(targetTile)){
					break;
				}
				findAdjacentTiles(current);
				for(Tile tile: adjacentTiles){
					if(closedList.contains(tile)){
						continue;
					}
					if(!openList.contains(tile)){
						tile.parent=current;
						tile.calculateFHG();
						openList.add(tile);
					}
					else{
						
					}	
				}
		}
		while(targetTile!=startTile){
			if(targetTile.parent!=null){
			targetTile= targetTile.parent;
			}
			else{
				break;
			}
			finalPath.add(targetTile);
		}
		for(Tile tile:openList){
			tile.direction=null;
		}
		for(Tile tile:closedList){
			tile.direction=null;
		}
	}
	
	public Tile findSmallestNode(){
		 Tile smallest=openList.get(0);
		for(int i=0;i<openList.size();i++){
			if(openList.get(i).Fscore<=smallest.Fscore){
				smallest=openList.get(i);
			}
		}
		return smallest;
	}
	
	public void move() {
		if(finalPath.size()>1){
		moveTo(finalPath.get(finalPath.size()-2));
		}
	}
	
	public void moveTo(Tile tile){
		if(centerX<tile.centerX){
			centerX+=speed;
		}
		if(centerX>tile.centerX){
			centerX-=speed;
		}
		if(centerY<tile.centerY){
			centerY+=speed;
		}
		if(centerY>tile.centerY){
			centerY-=speed;
		}
  }
	
	public boolean isInBounds(int y, int x){
		if(x<0 || x>27){
			return false;
		}
		else if(y<0 || y>30){
			return false;
		}
		return true;
	}
	public void deathAnimation(){
		
	}
}
