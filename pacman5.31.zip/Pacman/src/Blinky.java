
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Blinky extends Ghost {

	public Blinky() {
		try {
			this.image = ImageIO.read(new File("Blinky.png")).getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.centerX = Board.TILE_D * 13 + Board.TILE_D / 2;
		this.centerY = Board.TILE_D * 11 + Board.TILE_D / 2;
		this.dotLimit = 0;

	}

	public Tile findTargetTile() {
		if (inScatterMode && tileArray[centerY / Board.TILE_D][centerX / Board.TILE_D] != tileArray[1][26]) {
			return tileArray[1][26];
		} else if (inScatterMode) {
			return tileArray[2][21];
		}
		return tileArray[Pacman.centerY / Board.TILE_D][Pacman.centerX / Board.TILE_D];
	}

}
