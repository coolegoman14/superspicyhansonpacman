import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Board {
	static Tile[][] tileArray = new Tile[31][28];
	private static Image board;

	 {
		try {
			board = ImageIO.read(getClass().getResource("img/PacmanBoard.png"));
			// tile length and width is 8*3
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	static final int TILE_D = 24;//Tile dimensions 24x24
	private int foodSize = 13;
	private int maxSize = 18;
	private int minSize = 8;

	boolean isIncreasing;

	private static int[][] boardArray = { // 28--horizontal x 31--vertical
			/*
			 * 0=empty not null 1=wall 2=food 3=ghost killer food 4=ghost
			 * 5=ghost spawn point 6=only ghosts can go in here 7=portal
			 * 8=pacman spawn portal 9=pacman
			 */
			{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
			{ 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1 },
			{ 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1 },
			{ 1, 3, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 3, 1 },
			{ 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1 },
			{ 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1 },
			{ 1, 2, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 2, 1 },
			{ 1, 2, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 2, 1 },
			{ 1, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 0, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 1 },
			{ 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1 },
			{ 0, 0, 0, 0, 0, 1, 2, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 2, 1, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 1, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 1, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 1, 2, 1, 1, 0, 1, 1, 1, 7, 7, 1, 1, 1, 0, 1, 1, 2, 1, 0, 0, 0, 0, 0 },
			{ 1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 6, 0, 0, 0, 0, 6, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1 },
			{ 1, 7, 0, 0, 0, 0, 2, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 0, 7, 1 },
			{ 1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 6, 0, 0, 0, 0, 6, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1 },
			{ 0, 0, 0, 0, 0, 1, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 2, 1, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 1, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 1, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 1, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 2, 1, 0, 0, 0, 0, 0 },
			{ 1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1 },
			{ 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1 },
			{ 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1 },
			{ 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1 },
			{ 1, 3, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 0, 8, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 3, 1 },
			{ 1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1 },
			{ 1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1 },
			{ 1, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 1 },
			{ 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1 },
			{ 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1 },
			{ 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1 },
			{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },

	};

	public Board() {
		board.getScaledInstance((224) * 3, (248) * 3,
				Image.SCALE_SMOOTH);
		makeTileArray();

	}

	public void drawBoard(Graphics2D g) {

		g.drawImage(board, 0, 0, null);

		for (int i = 0; i < tileArray.length; i++) {
			for (int x = 0; x < tileArray[i].length; x++) {
				
				 /* if(tileArray[i][x].isWall){ g.setColor(Color.BLUE);
				 g.drawRect(tileArray[i][x].centerX-12, tileArray[i][x].centerY-12, TILE_D,
				  TILE_D); } else{ g.setColor(Color.MAGENTA);
				  g.drawRect(tileArray[i][x].centerX-12, tileArray[i][x].centerY-12, TILE_D,
				  TILE_D); }
				 */
				if (tileArray[i][x].isFood) {
					g.setColor(Color.WHITE);
					g.drawOval(tileArray[i][x].centerX - 1, tileArray[i][x].centerY - 1, 5, 5);
					g.fillOval(tileArray[i][x].centerX - 1, tileArray[i][x].centerY - 1, 5, 5);

				}
				if (tileArray[i][x].isGhostKiller) {
					g.setColor(Color.WHITE);
					g.drawOval(tileArray[i][x].centerX - 4, tileArray[i][x].centerY - 2, foodSize, foodSize);
					g.fillOval(tileArray[i][x].centerX - 4, tileArray[i][x].centerY - 2, foodSize, foodSize);
				}

			}
		}
		foodAnimation();

		g.setFont(new Font("Arial", 100, 100));
		g.drawString("SCORE: " + Pacman.points, 800, 100);

	}

	public static void makeTileArray() {
		for (int i = 0; i < boardArray.length; i++) {
			for (int x = 0; x < boardArray[i].length; x++) {
				Tile tile = new Tile(TILE_D * x, TILE_D * i);
				if (boardArray[i][x] == 1) {
					tile.isWall = true;
				}
				if (boardArray[i][x] == 2) {
					tile.isFood = true;
				}
				if (boardArray[i][x] == 3) {
					tile.isGhostKiller = true;
				}
				if (boardArray[i][x] == 7) {
					tile.isPortal = true;
				}
				tileArray[i][x] = tile;
			}
		}
	}
	
	public static void resetTileArray(){
		for (int i = 0; i < boardArray.length; i++) {
			for (int x = 0; x < boardArray[i].length; x++) {
				if (boardArray[i][x] == 2) {
					tileArray[i][x].isFood = true;
				}
				if (boardArray[i][x] == 3) {
					tileArray[i][x].isGhostKiller = true;
				}
				if (boardArray[i][x] == 7) {
					tileArray[i][x].isPortal = true;
				}
			}
		}
	}

	public void foodAnimation() {

		if (foodSize == maxSize) {
			isIncreasing = false;
		} else if (foodSize == minSize) {
			isIncreasing = true;
		}
		if (isIncreasing) {
			foodSize += 1;

		} else {
			foodSize -= 1;
		}
	}

	public void drawGhostPath(Graphics2D g) {
		/*
		 * for(Tile tile: Blinky.finalPath){ g.setColor(Color.red);
		 * g.fillRect(tile.centerX, tile.centerY, Board.TILE_D-5,
		 * Board.TILE_D-5); }
		 * 
		 * 
		 * Blinky.finalPath.clear();
		 */

	}

	public static Tile[][] cloneTile() {

		Tile[][] newBoard = new Tile[31][28];
		for (int i = 0; i < tileArray.length; i++) {
			for (int x = 0; x < tileArray[i].length; x++) {
				newBoard[i][x] = tileArray[i][x];
			}
		}
		return newBoard;
	}
}
