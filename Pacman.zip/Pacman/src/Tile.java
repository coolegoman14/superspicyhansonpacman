
public class Tile {

	
	boolean isWall;
	boolean isFood;
	int x;
	int y;
	int centerX;
	int centerY;
	int H;
	
	public Tile(int x, int y) {
		this.x=x;
		this.y=y;
		this.centerX=x+Board.TILE_D/2;
		this.centerY=y+Board.TILE_D/2;
	}
}
