import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;

public class Blinky extends Ghost{
		
	
	int x=36;
	int y=36;
	
	Rectangle clone;
	Direction direction=Ghost.Direction.RIGHT;
	Direction futureDirection;
	List<Tile> openList= new ArrayList<Tile>();
	List<Tile> closedList= new ArrayList<Tile>();

	public Blinky(Pacman pacman) {
		super(pacman);
		clone= new Rectangle();
	}
	
	public void draw(Graphics2D g){
		
		
		move();
		clone.setFrameFromCenter(x+16, y+16, x, y);
		g.setColor(Color.DARK_GRAY);
		//g.draw(clone);
		g.drawImage(Blinky, x-5, y-3, null);
	}
	
	public void move() {
		changeLists();
		for(Tile tile: openList){
			int x= Math.abs(tile.centerX-Pacman.centerX);
			int y= Math.abs(tile.centerY-Pacman.centerY);
			double distance= Math.sqrt((x^2)+(y^2));
		}
		
		
	}
	public void changeLists(){
		closedList.add(Board.tileArray[y/Board.TILE_D][x/Board.TILE_D]);
		if(canMove(Ghost.Direction.RIGHT)){
			openList.add(Board.tileArray[y/Board.TILE_D][(x/Board.TILE_D)+1]);
		}
		if(canMove(Ghost.Direction.LEFT)){
			openList.add(Board.tileArray[y/Board.TILE_D][(x/Board.TILE_D)-1]);
		}
		if(canMove(Ghost.Direction.UP)){
			openList.add(Board.tileArray[(y/Board.TILE_D)-1][x/Board.TILE_D]);
		}
		if(canMove(Ghost.Direction.DOWN)){
			openList.add(Board.tileArray[(y/Board.TILE_D)+1][(x/Board.TILE_D)+1]);
		}
	}
	}

