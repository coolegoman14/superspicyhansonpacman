
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Clyde extends Ghost {

	public Clyde() {
		try {
			this.image = ImageIO.read(getClass().getResource("img/Clyde.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.initialCenterX = Board.TILE_D * 15 + Board.TILE_D / 2;
		this.initialCenterY = Board.TILE_D * 13 + Board.TILE_D / 2;
		this.centerX = initialCenterX;
		this.centerY = initialCenterY;
		this.dotLimit = 60;
		allGhosts.add(this);
	}

	public Tile findTargetTile() {
		if (inScatterMode && Board.tileArray[centerY / Board.TILE_D][centerX / Board.TILE_D] != Board.tileArray[29][1]) {
			return Board.tileArray[29][1];
		} else if (inScatterMode) {
			return Board.tileArray[28][1];
		}

		int deltaX = Math.abs(Pacman.centerX - centerX);
		int deltaY = Math.abs(Pacman.centerY - centerY);
		double distance = Math.sqrt((deltaX * deltaX) + (deltaY * deltaY));
		if (distance > 34 * 8) {
			return Board.tileArray[Pacman.centerY / Board.TILE_D][Pacman.centerX / Board.TILE_D];
		}
		return Board.tileArray[29][1];
	}
}
