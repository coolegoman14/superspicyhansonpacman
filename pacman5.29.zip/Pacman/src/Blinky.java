
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Blinky extends Ghost{
	
	Rectangle clone;
	
	public Blinky() {
		try {
			this.image=ImageIO.read(new File("Blinky.png")).getScaledInstance(50, 50,Image.SCALE_SMOOTH);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.centerX=Board.TILE_D*13+Board.TILE_D/2;
		this.centerY=Board.TILE_D*11+Board.TILE_D/2;
		//this.direction=Ghost.Direction.RIGHT;
		clone= new Rectangle();
	}
	
	public void draw(Graphics2D g){
		
		findPath();
	    move();
		
		
		/*clone.setFrame(centerX, centerY, 5, 5);
		clone.setFrameFromCenter(centerX, centerY, centerX, centerY);
		g.draw(clone);*/
		g.drawImage(image, centerX-10, centerY-6, null);
		openList.clear();
		closedList.clear();
		
	}
	public Tile findTargetTile(){
		return Board.tileArray[Pacman.centerY/Board.TILE_D][Pacman.centerX/Board.TILE_D];	
	}
	
}

