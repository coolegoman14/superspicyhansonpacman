import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractAction;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.KeyStroke;


public class StartPacc {

	private JFrame frame = new JFrame("PAC-MAN");
	private JPanel panel;
	Board board = new Board();
	Pacman pacman = new Pacman();
	Blinky blinky = new Blinky();
	Pinky pinky = new Pinky();
	Inky inky = new Inky(blinky);
	Clyde clyde = new Clyde();
	Timers timer;
	int time = 0;
	Sound[] master = new Sound[10];
	{
		master[0] = new Sound("intro.wav");
		master[1] = new Sound("SirenSound.wav");
		master[2] = new Sound("wakaflocka.wav");
		master[3] = new Sound("death.wav");
	}

	public StartPacc() {

	}

	public static void main(String[] args) {
		new StartPacc().startGame();
	}

	@SuppressWarnings("serial")
	private void startGame() {

		panel = new JPanel() {
			@Override
			public void paintComponent(Graphics g) {
				super.paintComponent(g);
				board.drawBoard((Graphics2D) g);
				board.drawGhostPath((Graphics2D) g);
				pacman.draw((Graphics2D) g);
				blinky.draw((Graphics2D) g);
				pinky.draw((Graphics2D) g);
				inky.draw((Graphics2D) g);
				clyde.draw((Graphics2D) g);
			}
		};
		setUpGame();

		setUpKeyMappings();
		timer.createMovementTimer();
		timer.createScatterTimer();
	}

	@SuppressWarnings("serial")
	private void setUpKeyMappings() {

		panel.getInputMap().put(KeyStroke.getKeyStroke("LEFT"), "left");
		panel.getInputMap().put(KeyStroke.getKeyStroke("RIGHT"), "right");
		panel.getInputMap().put(KeyStroke.getKeyStroke("UP"), "up");
		panel.getInputMap().put(KeyStroke.getKeyStroke("DOWN"), "down");

		panel.getActionMap().put("left", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pacman.userDirection = Pacman.Direction.LEFT;
				if (pacman.canMove(Pacman.Direction.LEFT)) {
					Pacman.direction = Pacman.Direction.LEFT;
					pacman.changeAngleAttributes(Pacman.Direction.LEFT);
				}
			}
		});
		panel.getActionMap().put("right", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pacman.userDirection = Pacman.Direction.RIGHT;
				if (pacman.canMove(Pacman.Direction.RIGHT)) {
					Pacman.direction = Pacman.Direction.RIGHT;
					pacman.changeAngleAttributes(Pacman.Direction.RIGHT);
				}

			}
		});
		panel.getActionMap().put("up", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pacman.userDirection = Pacman.Direction.UP;
				if (pacman.canMove(Pacman.Direction.UP)) {
					Pacman.direction = Pacman.Direction.UP;
					pacman.changeAngleAttributes(Pacman.Direction.UP);
				}
			}
		});
		panel.getActionMap().put("down", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pacman.userDirection = Pacman.Direction.DOWN;
				if (pacman.canMove(Pacman.Direction.DOWN)) {
					Pacman.direction = Pacman.Direction.DOWN;
					pacman.changeAngleAttributes(Pacman.Direction.DOWN);
				}
			}
		});
		panel.requestFocusInWindow();
	}

	private void setUpGame() {
		board.makeTileArray();
		timer = new Timers(pacman, panel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(panel);
		panel.setPreferredSize(new Dimension(1500, 800));
		frame.pack();
		frame.setVisible(true);
		panel.setBackground(Color.black);
		this.setUpKeyMappings();
	}

}
