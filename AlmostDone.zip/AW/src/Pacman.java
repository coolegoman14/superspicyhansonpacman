import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Pacman {

	static Direction direction = Pacman.Direction.LEFT;
	Direction userDirection;
	boolean isIncreasing = true;
	static boolean isDead;
	int startAngle = 0;
	int arcAngle = 360;
	int maxStartAngle = 70;
	int minStartAngle = 290;
	static int initialCenterX= Board.TILE_D * 13 + Board.TILE_D / 2;
	static int initialCenterY=Board.TILE_D * 23 + Board.TILE_D / 2;
	static int centerX =initialCenterX;
	static int centerY = initialCenterY;
	private static int size=35;
	int speed = 6;
	static int points;
	Rectangle clone;

	enum Direction {
		RIGHT, LEFT, UP, DOWN;
	}

	public Pacman() {
		clone = new Rectangle(new Dimension(35, 35));
	}

	public void draw(Graphics2D g) {
		if(isDead || Ghost.dotCounter==244){
			deathAnimation();
		}
		g.setColor(Color.yellow);
		clone.setLocation(centerX - 15, centerY - 15);
		// g.draw(clone);
		g.drawArc(centerX - 15, centerY - 17, size, size, startAngle, arcAngle);
		g.fillArc(centerX - 15, centerY - 17, size, size, startAngle, arcAngle);

	}

	public void doMouthAnimation() {
		if (startAngle == maxStartAngle) {
			isIncreasing = false;
		} else if (startAngle == minStartAngle) {
			isIncreasing = true;
		}

		if (isIncreasing) {
			startAngle += 10;
			arcAngle -= 20;
		} else {
			startAngle -= 10;
			arcAngle += 20;
		}
	}

	public void move() {
		if (direction == Pacman.Direction.RIGHT) {
			if (canMove(direction)) {
				centerX += speed;
			}
		}

		if (direction == Pacman.Direction.LEFT) {
			if (canMove(direction)) {
				centerX -= speed;
			}

		}

		if (direction == Pacman.Direction.UP) {
			if (canMove(direction)) {
				centerY -= speed;
			}
		}

		if (direction == Pacman.Direction.DOWN) {
			if (canMove(direction)) {
				centerY += speed;
			}
		}
		checkIfPortal();
		checkCollision();
	}

	public void changeAngleAttributes(Direction direction) {
		if (direction == Pacman.Direction.RIGHT) {
			startAngle = 0;
		}

		if (direction == Pacman.Direction.LEFT) {
			startAngle = 180;
		}

		if (direction == Pacman.Direction.UP) {
			startAngle = 90;
		}

		if (direction == Pacman.Direction.DOWN) {
			startAngle = 270;
		}
		arcAngle = 360;
		maxStartAngle = startAngle + 70;
		minStartAngle = startAngle;
	}

	public Boolean canMove(Pacman.Direction desiredDirection) {
		eatFood();
		if (desiredDirection == Pacman.Direction.RIGHT) {
			if (direction != desiredDirection) {
				if (Board.tileArray[centerY / Board.TILE_D][(centerX / Board.TILE_D) + 1].isWall) {
					return false;
				}
			} else if (Board.tileArray[centerY / Board.TILE_D][centerX / Board.TILE_D].centerX == centerX
					&& Board.tileArray[centerY / Board.TILE_D][(centerX / Board.TILE_D) + 1].isWall) {
				return false;
			}
		} else if (desiredDirection == Pacman.Direction.LEFT) {
			if (direction != desiredDirection) {
				if (Board.tileArray[centerY / Board.TILE_D][(centerX / Board.TILE_D) - 1].isWall) {
					return false;
				}
			} else if (Board.tileArray[centerY / Board.TILE_D][centerX / Board.TILE_D].centerX == centerX
					&& Board.tileArray[centerY / Board.TILE_D][(centerX / Board.TILE_D) - 1].isWall) {
				return false;
			}
		} else if (desiredDirection == Pacman.Direction.UP) {
			if (direction != desiredDirection) {
				if (Board.tileArray[(centerY / Board.TILE_D) - 1][centerX / Board.TILE_D].isWall) {
					return false;
				}
			} else if (Board.tileArray[centerY / Board.TILE_D][centerX / Board.TILE_D].centerY == centerY
					&& Board.tileArray[(centerY / Board.TILE_D) - 1][centerX / Board.TILE_D].isWall) {
				return false;
			}
		} else if (desiredDirection == Pacman.Direction.DOWN) {
			if (direction != desiredDirection) {
				if (Board.tileArray[(centerY / Board.TILE_D) + 1][centerX / Board.TILE_D].isWall) {
					return false;
				}
			} else if (Board.tileArray[centerY / Board.TILE_D][centerX / Board.TILE_D].centerY == centerY
					&& Board.tileArray[(centerY / Board.TILE_D) + 1][centerX / Board.TILE_D].isWall) {
				return false;
			}
		}

		return true;
	}

	private void eatFood() {
		if (Board.tileArray[(centerY) / Board.TILE_D][centerX / Board.TILE_D].isFood) {
			Board.tileArray[(centerY) / Board.TILE_D][centerX / Board.TILE_D].isFood = false;
			points += 10;
			Ghost.dotCounter++;
			//StartPacc.playChomp();
		}
		if (Board.tileArray[(centerY) / Board.TILE_D][centerX / Board.TILE_D].isGhostKiller) {
			Ghost.dotCounter++;
			Timers.interval=0;
		//	StartPacc.playChomp();
			for(Ghost g:Ghost.allGhosts){
				g.makeScared();
			}
			Board.tileArray[(centerY) / Board.TILE_D][centerX / Board.TILE_D].isGhostKiller = false;
		}
	}

	public void checkIfPortal() {
		if (Board.tileArray[centerY / Board.TILE_D][centerX / Board.TILE_D].isPortal) {
			if (centerX / Board.TILE_D == 1) {
				centerX = 26 * Board.TILE_D;
				direction = Direction.LEFT;
			} else {
				centerX = Board.TILE_D * 2;
				direction = Direction.RIGHT;
			}
		}
	}

	private void checkCollision() {

		for (Ghost g : Ghost.allGhosts) {
			if (clone.intersects(g.clone)) {
				if (g.isScared) {
					points += 200;
					StartPacc.playEatGhost();
					g.isEaten = true;
				} else if (!(g.isScared || g.isEaten)) {
					StartPacc.playDeath();
					deathAnimation();
					StartPacc.lives--;
					
					
				}
			}
		}
	}
	private void deathAnimation(){
		if(StartPacc.lives == 0) {
			StartPacc.gameOver = true;
			StartPacc.fullReset();
		}
		isDead = true;
		Timers.movementTimer.setDelay(100);
		size--;
		if(size==0){
			StartPacc.resetGame();
		}
	}
	public static void resetPacman(){
		isDead=false;
		centerX =initialCenterX;
		centerY =initialCenterY;
		size=35;
	}
}
