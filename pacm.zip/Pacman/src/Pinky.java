import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;


public class Pinky extends Ghost {
	
	
	int x=50;
	int y=120;
	
	Rectangle clone;
	Direction direction=Ghost.Direction.RIGHT;
	Direction futureDirection;
	
	
	public Pinky(Pacman pacman) {
		super(pacman);
		clone= new Rectangle();
	}
	
	public void draw(Graphics2D g){
		
		
		move();
		clone.setFrameFromCenter(x+16, y+16, x, y);
		g.setColor(Color.DARK_GRAY);
		//g.draw(clone);
		g.drawImage(Pinky, x-5, y-3, null);
	}
	
	public void move() {
		if(x!=pacman.x){
			if(x<pacman.x && canMove(Ghost.Direction.RIGHT) && direction!=Ghost.Direction.LEFT){
				x+=speed;
			}
			else if(x>pacman.x && canMove(Ghost.Direction.LEFT)){
				x-=speed;
			}
		}
		if(y!=pacman.y){
			if(y<pacman.y && canMove(Ghost.Direction.DOWN) &&direction!=Ghost.Direction.UP){
				y+=speed;
			}
			else if(y>pacman.y && canMove(Ghost.Direction.UP)){
				y-=speed;
			}
		}
	}
}
