
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Pinky extends Ghost {

	public Pinky() {
		try {
			this.image = ImageIO.read(new File("Pinky.png")).getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.initialCenterX=Board.TILE_D * 13 + Board.TILE_D / 2;
		this.initialCenterY=Board.TILE_D * 14 + Board.TILE_D / 2;
		this.centerX = initialCenterX;
		this.centerY = initialCenterY;
		this.dotLimit = 0;
		allGhosts.add(this);
	}

	private Tile findTile(int x, int y) {
		for (int i = 4; i > -1; i--) {
			if (isInBounds((Pacman.centerY / Board.TILE_D) + i * y, (Pacman.centerX / Board.TILE_D) + i * x)) {
				if (!Board.tileArray[(Pacman.centerY / Board.TILE_D) + i * y][(Pacman.centerX / Board.TILE_D)
						+ i * x].isWall) {
					return Board.tileArray[(Pacman.centerY / Board.TILE_D) + i * y][(Pacman.centerX / Board.TILE_D) + i * x];
				}
			}
		}
		return null;
	}

	public Tile findTargetTile() {
		if (inScatterMode && Board.tileArray[centerY / Board.TILE_D][centerX / Board.TILE_D] != Board.tileArray[1][1]) {
			return Board.tileArray[1][1];
		} else if (inScatterMode) {
			return Board.tileArray[1][2];

		}

		if (Pacman.direction == Pacman.Direction.RIGHT) {
			return this.findTile(1, 0);
		}
		if (Pacman.direction == Pacman.Direction.LEFT) {
			return this.findTile(-1, 0);
		}
		if (Pacman.direction == Pacman.Direction.UP) {
			return this.findTile(0, -1);
		}
		return this.findTile(0, 1);
	}
}
