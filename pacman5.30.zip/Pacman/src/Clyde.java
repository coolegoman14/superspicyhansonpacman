
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Clyde extends Ghost {
	
	
	int x=45;
	int y=80;
	
	Rectangle clone;
	

	public Clyde() {
		try {
			this.image=ImageIO.read(new File("Clyde.png")).getScaledInstance(50, 50,Image.SCALE_SMOOTH);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.centerX=Board.TILE_D*14+Board.TILE_D/2;
		this.centerY=Board.TILE_D*13+Board.TILE_D/2;
		
		clone= new Rectangle();
	}
	public void draw(Graphics2D g){
		
		findPath();
		move();
		/*clone.setFrameFromCenter(x+16, y+16, x, y);
		g.setColor(Color.DARK_GRAY);
		g.draw(clone);*/
		g.drawImage(image, centerX-12, centerY-12, null);
		finalPath.clear();
		openList.clear();
		closedList.clear();
	}
	
	public Tile findTargetTile() {
		int deltaX=Math.abs(Pacman.centerX - centerX);
		int deltaY=Math.abs(Pacman.centerY - centerY);
		double distance= Math.sqrt((deltaX*deltaX)+(deltaY*deltaY));
		if(distance>34*8){
			return tileArray[Pacman.centerY/Board.TILE_D][Pacman.centerX/Board.TILE_D];	
		}
		return tileArray[29][1];	
	}
}
