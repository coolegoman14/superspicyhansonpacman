import java.awt.Image;

import java.util.ArrayList;
import java.util.List;
public abstract class Ghost {
	
	Image image;
	int speed=6;
	int centerX;
	int centerY;
	Direction direction;
	List<Tile> openList= new ArrayList<Tile>();
	List<Tile> closedList= new ArrayList<Tile>();
	List<Tile> adjacentTiles= new ArrayList<Tile>();
    List<Tile> finalPath= new ArrayList<Tile>();
	Tile smallest, current, targetTile;
	
	enum Direction{
		RIGHT,LEFT,UP,DOWN;
	}
	public Ghost() {
		
		
	}
	public abstract Tile findTargetTile();
	
public Boolean canMove(Tile.Direction desiredDirection,Tile tile){
		if(desiredDirection==Tile.Direction.RIGHT ){
			if(tile.direction==Tile.Direction.LEFT){
				return false;		
			}
			if(Board.tileArray[tile.centerY/Board.TILE_D][(tile.centerX/Board.TILE_D)+1].isWall){
				return false;
			}
			/*else if(Board.tileArray[tile.centerY/Board.TILE_D][tile.centerX/Board.TILE_D].centerX==centerX && Board.tileArray[tile.centerY/Board.TILE_D][(centerX/Board.TILE_D)+1].isWall){
				System.out.println("here");
				return false;
			}*/
		}
		if(desiredDirection==Tile.Direction.LEFT ){
			if(tile.direction==Tile.Direction.RIGHT){
				return false;	
			}
			if(Board.tileArray[tile.centerY/Board.TILE_D][(tile.centerX/Board.TILE_D)-1].isWall){
				return false;
			}
			/*else if(Board.tileArray[tile.centerY/Board.TILE_D][tile.centerX/Board.TILE_D].centerX==centerX && Board.tileArray[tile.centerY/Board.TILE_D][(tile.centerX/Board.TILE_D)-1].isWall){
				return false;
			}*/
		}
		if(desiredDirection==Tile.Direction.UP ){
			if(tile.direction==Tile.Direction.DOWN){
				return false;	
			}
			if(Board.tileArray[(tile.centerY/Board.TILE_D)-1][tile.centerX/Board.TILE_D].isWall){
				return false;
			}
			/*else if(Board.tileArray[tile.centerY/Board.TILE_D][tile.centerX/Board.TILE_D].centerY==centerY && Board.tileArray[(tile.centerY/Board.TILE_D)-1][tile.centerX/Board.TILE_D].isWall){
				return false;
			}*/
		}
		if(desiredDirection==Tile.Direction.DOWN ){
			if(tile.direction==Tile.Direction.UP){
				return false;
				
			}
			if(Board.tileArray[(tile.centerY/Board.TILE_D)+1][tile.centerX/Board.TILE_D].isWall){
				return false;
			}
			/*else if(Board.tileArray[tile.centerY/Board.TILE_D][tile.centerX/Board.TILE_D].centerY==centerY && Board.tileArray[(tile.centerY/Board.TILE_D)+1][tile.centerX/Board.TILE_D].isWall){
				return false;
			}*/
		}
		
		return true;
	}

	public void findAdjacentTiles(Tile current){
		adjacentTiles.clear();
		if(canMove(Tile.Direction.RIGHT,current)){
			Board.tileArray[current.centerY/Board.TILE_D][(current.centerX/Board.TILE_D)+1].direction=Tile.Direction.RIGHT;
			adjacentTiles.add(Board.tileArray[current.centerY/Board.TILE_D][(current.centerX/Board.TILE_D)+1]);
		}
		if(canMove(Tile.Direction.LEFT,current)){
			Board.tileArray[current.centerY/Board.TILE_D][(current.centerX/Board.TILE_D)-1].direction=Tile.Direction.LEFT;
			adjacentTiles.add(Board.tileArray[current.centerY/Board.TILE_D][(current.centerX/Board.TILE_D)-1]);
		}
		if(canMove(Tile.Direction.UP,current)){
			Board.tileArray[(current.centerY/Board.TILE_D)-1][current.centerX/Board.TILE_D].direction=Tile.Direction.UP;
			adjacentTiles.add(Board.tileArray[(current.centerY/Board.TILE_D)-1][current.centerX/Board.TILE_D]);
		}
		if(canMove(Tile.Direction.DOWN,current)){
			Board.tileArray[(current.centerY/Board.TILE_D)+1][current.centerX/Board.TILE_D].direction=Tile.Direction.DOWN;
			adjacentTiles.add(Board.tileArray[(current.centerY/Board.TILE_D)+1][current.centerX/Board.TILE_D]);
		}
	}
	public void findPath(){
		Tile startTile=Board.tileArray[centerY/Board.TILE_D][centerX/Board.TILE_D];
		targetTile= findTargetTile();
		openList.add(startTile);

		while(!openList.isEmpty()){
			 current=findSmallestNode();
			openList.remove(current);
			closedList.add(current);
				if(closedList.contains(targetTile)){
					break;
				}
				findAdjacentTiles(current);
				for(Tile tile: adjacentTiles){
					if(closedList.contains(tile)){
						continue;
					}
					if(!openList.contains(tile)){
						tile.parent=current;
						tile.calculateFHG();
						openList.add(tile);
					}
					else{
						
					}	
				}
		}
		while(targetTile!=startTile){
			if(targetTile.parent!=null){
			targetTile= targetTile.parent;
			}
			else{
				break;
			}
			finalPath.add(targetTile);
		}
	}
	
	public Tile findSmallestNode(){
		 smallest=openList.get(0);
		for(int i=0;i<openList.size();i++){
			if(openList.get(i).Fscore<=smallest.Fscore){
				smallest=openList.get(i);
			}
		}
		return smallest;
	}
	public void move() {
		if(finalPath.size()>1){
		moveTo(finalPath.get(finalPath.size()-2));
		}
	}
	
	public void moveTo(Tile tile){
		if(centerX<tile.centerX){
			centerX+=speed;
		}
		if(centerX>tile.centerX){
			centerX-=speed;
		}
		if(centerY<tile.centerY){
			centerY+=speed;
		}
		if(centerY>tile.centerY){
			centerY-=speed;
		}
  }
	
	public boolean isInBounds(int y, int x){
		if(x<0 || x>27){
			return false;
		}
		else if(y<0 || y>30){
			return false;
		}
		return true;
	}
	public void deathAnimation(){
		
	}
}
