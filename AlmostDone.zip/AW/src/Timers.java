import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Timers {
	int scatterTime;
	int[] scatterTimesLEVEL1 = { 4, 20, 7, 20, 5, 20, 5 };
	int[] scatterTimesLEVEL2_4 = { 7, 20, 7, 20, 5, 1033, 1 };
	int[] scatterTimesLEVEL5_UP = { 5, 20, 5, 20, 5, 1037, 1 };

	static Timer movementTimer = new Timer(50, null);
	static Timer scatterTimer = new Timer(1000, null);
	static Timer frightenedTimer = new Timer(1000, null);
	Pacman pacman;
	JPanel panel;
	
	boolean inScatterMode = true;
	int i = 0;
	static int interval;

	public Timers(Pacman pacman, JPanel panel) {
		this.panel = panel;
		this.pacman = pacman;
	}

	void createMovementTimer() {
		movementTimer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				movementTick();
			}

		});
		movementTimer.start();
	}

	protected void movementTick() {
		
		

		if (Pacman.direction != pacman.userDirection && pacman.canMove(pacman.userDirection)) {
			Pacman.direction = pacman.userDirection;
			pacman.changeAngleAttributes(Pacman.direction);
		}
		if (pacman.isDead == false) {
			pacman.move();
			pacman.doMouthAnimation();
		}
		panel.repaint();
	}

	void createScatterTimer() {
		scatterTimer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				scatterTick();
			}
		});
		scatterTimer.start();
	}

	protected void scatterTick() {
		if (i == 7) {
			scatterTimer.stop();
		}
		if (scatterTime < scatterTimesLEVEL1[i]) {
			Ghost.inScatterMode = inScatterMode;
		} else {
			i++;
			inScatterMode = !inScatterMode;
			scatterTime = 0;
		}
		scatterTime++;
	}
	public static void createFrightenedTimer(int duration) {

		frightenedTimer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				frightenedTick(duration);
			}
		});
	}
	protected static void frightenedTick(int duration) {
		interval++;
		if (interval == duration) {
			for(Ghost g: Ghost.allGhosts){
				if(g.isScared){
					g.isScared=false;
					g.speed=6;
				}
			}
			interval=0;
			frightenedTimer.stop();
		}
	}
}
