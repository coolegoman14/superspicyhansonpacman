
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Inky extends Ghost {
	
	Blinky blinky;
	Rectangle clone;
	
	
	public Inky(Blinky blinky) {	
		try {
			this.image=ImageIO.read(new File("Inky.png")).getScaledInstance(50, 50,Image.SCALE_SMOOTH);
		} catch (IOException e) {
			e.printStackTrace();
	}
		this.centerX=Board.TILE_D*10+Board.TILE_D/2;
		this.centerY=Board.TILE_D*13+Board.TILE_D/2;
		this.blinky=blinky;
		
		clone= new Rectangle();
	}
	public void draw(Graphics2D g){
		
		findPath();
		move();
		/*clone.setFrameFromCenter(x+16, y+16, x, y);
		g.setColor(Color.DARK_GRAY);
		g.draw(clone);
*/		g.drawImage(image, centerX-12, centerY-12, null);
		openList.clear();
		closedList.clear();
	}
	private Tile findTile(int x,int y){
		for (int i =2 ;i>-1;i--){
			if(isInBounds((Pacman.centerY/Board.TILE_D)+i*y,(Pacman.centerX/Board.TILE_D)+ i* x)){
				if(!Board.tileArray[(Pacman.centerY/Board.TILE_D)+i*y][(Pacman.centerX/Board.TILE_D)+ i* x].isWall){
					return Board.tileArray[(Pacman.centerY/Board.TILE_D)+i*y][(Pacman.centerX/Board.TILE_D)+ i* x];
				}
			}
		}
		return null;	
	}
	@Override
	public Tile findTargetTile() {
		if(Pacman.direction==Pacman.Direction.RIGHT){
			targetTile=findTile(1,0);		
		}
		if(Pacman.direction==Pacman.Direction.LEFT){		
			targetTile=findTile(-1,0);	
		}
		if(Pacman.direction==Pacman.Direction.UP){	
			targetTile=findTile(0,-1);
		}
			int deltaX=Math.abs(targetTile.centerX - blinky.centerX);
			int deltaY=Math.abs(targetTile.centerY - blinky.centerY);
			if(isInBounds((targetTile.centerY+deltaY)/Board.TILE_D,(targetTile.centerX+deltaX)/Board.TILE_D)){
				return tileArray[(targetTile.centerY+deltaY)/Board.TILE_D][(targetTile.centerX+deltaX)/Board.TILE_D];
			}	
				return tileArray[Pacman.centerY/Board.TILE_D][Pacman.centerX/Board.TILE_D];
	}
}
