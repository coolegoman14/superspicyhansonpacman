
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Inky extends Ghost {

	Blinky blinky;

	public Inky(Blinky blinky) {
		try {
			this.image = ImageIO.read(new File("Inky.png")).getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.initialCenterX = Board.TILE_D * 11 + Board.TILE_D / 2;
		this.initialCenterY = Board.TILE_D * 13 + Board.TILE_D / 2;
		this.centerX = initialCenterX;
		this.centerY = initialCenterY;
		this.blinky = blinky;
		this.dotLimit = 30;
		allGhosts.add(this);
	}

	private Tile findTile(int x, int y) {
		for (int i = 2; i > -1; i--) {
			if (isInBounds((Pacman.centerY / Board.TILE_D) + i * y, (Pacman.centerX / Board.TILE_D) + i * x)) {
				if (!Board.tileArray[(Pacman.centerY / Board.TILE_D) + i * y][(Pacman.centerX / Board.TILE_D)
						+ i * x].isWall) {
					return Board.tileArray[(Pacman.centerY / Board.TILE_D) + i * y][(Pacman.centerX / Board.TILE_D) + i * x];
				}
			}
		}
		return null;
	}

	public Tile findTargetTile() {
		if (inScatterMode && Board.tileArray[centerY / Board.TILE_D][centerX / Board.TILE_D] != Board.tileArray[29][1]) {
			return Board.tileArray[29][26];
		} else if (inScatterMode) {
			return Board.tileArray[27][14];
		}
		if (Pacman.direction == Pacman.Direction.RIGHT) {
			targetTile = findTile(1, 0);
		}
		if (Pacman.direction == Pacman.Direction.LEFT) {
			targetTile = findTile(-1, 0);
		}
		if (Pacman.direction == Pacman.Direction.UP) {
			targetTile = findTile(0, -1);
		}
		if (Pacman.direction == Pacman.Direction.DOWN) {
			targetTile = findTile(0, 1);
		}
		int deltaX = Math.abs(targetTile.centerX - blinky.centerX);
		int deltaY = Math.abs(targetTile.centerY - blinky.centerY);
		if (isInBounds((targetTile.centerY + deltaY) / Board.TILE_D, (targetTile.centerX + deltaX) / Board.TILE_D)) {
			return Board.tileArray[(targetTile.centerY + deltaY) / Board.TILE_D][(targetTile.centerX + deltaX)
					/ Board.TILE_D];
		}
		return Board.tileArray[Pacman.centerY / Board.TILE_D][Pacman.centerX / Board.TILE_D];
	}
}
