
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.Timer;

public abstract class Ghost {

	Image image;
	Image frightened;
	Image ghostEyes;
	Rectangle clone = new Rectangle(new Dimension(40, 40));
	static int interval = 0;
	int speed = 6;
	int initialCenterX;
	int initialCenterY;
	int centerX;
	int centerY;
	int dotLimit;
	static int dotCounter;
	private List<Tile> openList = new ArrayList<Tile>(), closedList = new ArrayList<Tile>();
	private List<Tile> adjacentTiles = new ArrayList<Tile>(), finalPath = new ArrayList<Tile>();
	Tile current, targetTile, startTile;
	//Tile[][] tileArray;
	Tile.Direction previousDirection = Tile.Direction.RIGHT;
	boolean isScared;
	static boolean inScatterMode;
	boolean isEaten;
	static int scareTime = 10;
	Random random = new Random();
	private List<Tile> excludedTiles = new ArrayList<Tile>();
	static List<Ghost> allGhosts = new ArrayList<Ghost>();
	int i = 0;
	public Ghost() {
		try {
			this.ghostEyes= ImageIO.read(new File("ghostEyes.png")).getScaledInstance(50, 50, Image.SCALE_SMOOTH);
			this.frightened = ImageIO.read(new File("scaredGhost.gif")).getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		} catch (IOException e) {
			e.printStackTrace();
		}
		//this.tileArray = Board.cloneTile();
		for (int i = 0; i < Board.tileArray.length; i++) {
			for (int x = 0; x < Board.tileArray[i].length; x++) {
				if (Board.tileArray[i][x].isWall) {
					excludedTiles.add(Board.tileArray[i][x]);
				}
			}
		}
	}

	public abstract Tile findTargetTile();

	public void draw(Graphics2D g) {
		
		if(leftGhostHouse()){
			findPath();
			move();
		}
		clone.setLocation(centerX-10, centerY-15);
		drawGhost(g);
		openList.clear();
		closedList.clear();

	}

	public void makeScared() {
		isScared = true;
		Timers.frightenedTimer.start();
	}

	private boolean canMove(Tile.Direction desiredDirection, Tile tile) {
		if (desiredDirection == Tile.Direction.RIGHT) {
			if (tile.direction == Tile.Direction.LEFT) {
				return false;
			}
			if (Board.tileArray[tile.centerY / Board.TILE_D][(tile.centerX / Board.TILE_D) + 1].isWall) {
				return false;
			}
		}
		if (desiredDirection == Tile.Direction.LEFT) {
			if (tile.direction == Tile.Direction.RIGHT) {
				return false;
			}
			if (Board.tileArray[tile.centerY / Board.TILE_D][(tile.centerX / Board.TILE_D) - 1].isWall) {
				return false;
			}
		}
		if (desiredDirection == Tile.Direction.UP) {
			if (tile.direction == Tile.Direction.DOWN) {
				return false;
			}
			if (Board.tileArray[(tile.centerY / Board.TILE_D) - 1][tile.centerX / Board.TILE_D].isWall) {
				return false;
			}
		}
		if (desiredDirection == Tile.Direction.DOWN) {
			if (tile.direction == Tile.Direction.UP) {
				return false;

			}
			if (Board.tileArray[(tile.centerY / Board.TILE_D) + 1][tile.centerX / Board.TILE_D].isWall) {
				return false;
			}
		}

		return true;
	}

	private void findAdjacentTiles(Tile current) {
		adjacentTiles.clear();
		if (canMove(Tile.Direction.RIGHT, current)) {
			Board.tileArray[current.centerY / Board.TILE_D][(current.centerX / Board.TILE_D)
					+ 1].direction = Tile.Direction.RIGHT;
			adjacentTiles.add(Board.tileArray[current.centerY / Board.TILE_D][(current.centerX / Board.TILE_D) + 1]);
		}
		if (canMove(Tile.Direction.LEFT, current)) {
			Board.tileArray[current.centerY / Board.TILE_D][(current.centerX / Board.TILE_D)
					- 1].direction = Tile.Direction.LEFT;
			adjacentTiles.add(Board.tileArray[current.centerY / Board.TILE_D][(current.centerX / Board.TILE_D) - 1]);
		}
		if (canMove(Tile.Direction.UP, current)) {
			Board.tileArray[(current.centerY / Board.TILE_D) - 1][current.centerX
					/ Board.TILE_D].direction = Tile.Direction.UP;
			adjacentTiles.add(Board.tileArray[(current.centerY / Board.TILE_D) - 1][current.centerX / Board.TILE_D]);
		}
		if (canMove(Tile.Direction.DOWN, current)) {
			Board.tileArray[(current.centerY / Board.TILE_D) + 1][current.centerX
					/ Board.TILE_D].direction = Tile.Direction.DOWN;
			adjacentTiles.add(Board.tileArray[(current.centerY / Board.TILE_D) + 1][current.centerX / Board.TILE_D]);
		}
	}

	public void findPath() {
		startTile = Board.tileArray[centerY / Board.TILE_D][centerX / Board.TILE_D];
		startTile.direction = previousDirection;
		finalPath.clear();
		 if(isEaten) {
			targetTile = Board.tileArray[14][14];
		}
		else{
			targetTile=findTargetTile();
		}
		finalPath.add(targetTile);
		openList.add(startTile);

		while (!openList.isEmpty()) {
			current = findSmallestNode();
			openList.remove(current);
			closedList.add(current);
			if (closedList.contains(targetTile)) {
				break;
			}
			findAdjacentTiles(current);
			for (Tile tile : adjacentTiles) {
				if (closedList.contains(tile)) {
					continue;
				}
				if (!openList.contains(tile)) {
					tile.parent = current;
					tile.calculateFHG();
					openList.add(tile);
				} else {

				}
			}
		}
		addToFinalPath();
	}

	private Tile findSmallestNode() {
		Tile smallest = openList.get(0);
		for (int i = 0; i < openList.size(); i++) {
			if (openList.get(i).Fscore <= smallest.Fscore) {
				smallest = openList.get(i);
			}
		}
		return smallest;
	}

	private void addToFinalPath() {
		while (targetTile != startTile) {
			if (targetTile.parent != null) {
				targetTile = targetTile.parent;
			} else {
				break;
			}
			finalPath.add(targetTile);
		}
	}

	public void move() {
		if(isScared){
			startTile=Board.tileArray[centerY/Board.TILE_D][centerX/Board.TILE_D];
			startTile.direction=previousDirection;
			if(canMove(Tile.Direction.RIGHT,startTile)){
				centerX+=speed;
			}
			else if (canMove(Tile.Direction.LEFT,startTile)){
				centerX-=speed;
			}
			else if(canMove(Tile.Direction.UP,startTile)){
				centerY-=speed;
			}
			else if(canMove(Tile.Direction.DOWN,startTile)){
				centerY+=speed;
			}
			previousDirection=Board.tileArray[centerY/Board.TILE_D][centerX/Board.TILE_D].direction;
		}
		else if (finalPath.size() > 1) {
			moveTo(finalPath.get(finalPath.size() - 2));
		}
	}

	private void moveTo(Tile tile) {
		
		if ( centerX!=tile.centerX &&centerX < tile.centerX) {
			centerX += speed;
		}
		if ( centerX!=tile.centerX &&centerX > tile.centerX ) {
			centerX -= speed;
		}
		if (centerY!=tile.centerY&& centerY < tile.centerY) {
			centerY += speed;
		}
		if (centerY!=tile.centerY &&centerY > tile.centerY) {
			centerY -= speed;
		}
		previousDirection=Board.tileArray[centerY/Board.TILE_D][centerX/Board.TILE_D].direction;
	}

	public boolean isInBounds(int y, int x) {
		if (x < 0 || x > 27) {
			return false;
		} else if (y < 0 || y > 30) {
			return false;
		}
		return true;
	}

	public void drawGhost(Graphics2D g) {
		if (isEaten) {
			speed=10;
			g.drawImage(ghostEyes, centerX - 10, centerY - 6, null);
			eyesGoToDen();
		} else if (isScared) {
			speed=3;
			g.drawImage(frightened, centerX - 12, centerY - 12, null);
		} else {
			g.drawImage(image, centerX - 12, centerY - 12, null);
		}
	}

	private void eyesGoToDen() {
		isScared=false;
		if(Board.tileArray[centerY/Board.TILE_D][centerX/Board.TILE_D]==Board.tileArray[14][14]){
			speed=6;
			isEaten=false;
		}
	}
	
	private boolean leftGhostHouse(){
		i++;
		if (dotCounter >= dotLimit) {
			i=0;
			return true;
		} else if (i % 3 == 0) {
			if (centerY == Board.TILE_D * 13 + Board.TILE_D / 2) {
				moveTo(Board.tileArray[(centerY / Board.TILE_D) + 1][centerX / Board.TILE_D]);
			} else {
				moveTo(Board.tileArray[(centerY / Board.TILE_D) - 1][centerX / Board.TILE_D]);
			}
		}
		return false;
	}
	
	public static void resetGhosts(){
		dotCounter = 0;
		for (Ghost g : allGhosts) {
			g.speed=6;
			g.centerX = g.initialCenterX;
			g.centerY = g.initialCenterY;
			g.isScared = false;
			g.isEaten = false;
		}
	}
}
