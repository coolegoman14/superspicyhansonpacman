import java.awt.Image;
import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public abstract class Ghost {
	
	Image Blinky;
	Image Pinky;
	Image Clyde;
	Image Inky;
	Pacman pacman;
	int speed=6;
	int centerX=Board.TILE_D+Board.TILE_D/2;
	int centerY=Board.TILE_D+Board.TILE_D/2;
	Direction direction;
	
	enum Direction{
		RIGHT,LEFT,UP,DOWN;
	}
	public Ghost(Pacman pacman) {
		this.pacman=pacman;
		try {
			
			Blinky=ImageIO.read(new File("Blinky.png")).getScaledInstance(50, 50,Image.SCALE_SMOOTH);
			Pinky=ImageIO.read(new File("Pinky.png")).getScaledInstance(40, 40,Image.SCALE_SMOOTH);
			Clyde=ImageIO.read(new File("Clyde.png")).getScaledInstance(40, 40,Image.SCALE_SMOOTH);
			Inky=ImageIO.read(new File("Inky.png")).getScaledInstance(50, 50,Image.SCALE_SMOOTH);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	public Boolean canMove(Ghost.Direction d){
		
		if(d==Ghost.Direction.RIGHT ){
			if(direction!=Ghost.Direction.RIGHT){
				if(Board.tileArray[centerY/Board.TILE_D][(centerX/Board.TILE_D)+1].isWall){
					return false;
				}
			}
			else if(Board.tileArray[centerY/Board.TILE_D][centerX/Board.TILE_D].centerX==centerX && Board.tileArray[centerY/Board.TILE_D][(centerX/Board.TILE_D)+1].isWall){
				return false;
			}
		}
		if(d==Ghost.Direction.LEFT ){
			if(direction!=Ghost.Direction.LEFT){
				if(Board.tileArray[centerY/Board.TILE_D][(centerX/Board.TILE_D)-1].isWall){
					return false;
				}
			}
			else if(Board.tileArray[centerY/Board.TILE_D][centerX/Board.TILE_D].centerX==centerX && Board.tileArray[centerY/Board.TILE_D][(centerX/Board.TILE_D)-1].isWall){
				return false;
			}
		}
		if(d==Ghost.Direction.UP ){
			if(direction!=Ghost.Direction.UP){
				if(Board.tileArray[(centerY/Board.TILE_D)-1][centerX/Board.TILE_D].isWall){
					return false;
				}
			}
			else if(Board.tileArray[centerY/Board.TILE_D][centerX/Board.TILE_D].centerY==centerY && Board.tileArray[(centerY/Board.TILE_D)-1][centerX/Board.TILE_D].isWall){
				return false;
			}
		}
		if(d==Ghost.Direction.DOWN ){
			if(direction!=Ghost.Direction.DOWN){
				if(Board.tileArray[(centerY/Board.TILE_D)+1][centerX/Board.TILE_D].isWall){
					return false;
				}
			}
			else if(Board.tileArray[centerY/Board.TILE_D][centerX/Board.TILE_D].centerY==centerY && Board.tileArray[(centerY/Board.TILE_D)+1][centerX/Board.TILE_D].isWall){
				return false;
			}
		}
		
		return true;
	}
}
