
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;


public class Pinky extends Ghost {
	
	Rectangle clone;
	Direction direction=Ghost.Direction.RIGHT;
	
	public Pinky() {
		try {
			this.image=ImageIO.read(new File("Pinky.png")).getScaledInstance(40, 40,Image.SCALE_SMOOTH);
		} catch (IOException e) {
			e.printStackTrace();
		}
		clone= new Rectangle();
		this.centerX=Board.TILE_D*13+Board.TILE_D/2;
		this.centerY=Board.TILE_D*14+Board.TILE_D/2;
		//this.direction=Ghost.Direction.RIGHT;
		
	}
	
	public void draw(Graphics2D g){
		
		findPath();
		move();
		//clone.setFrameFromCenter(x+16, y+16, x, y);
		//g.setColor(Color.DARK_GRAY);
		//g.draw(clone);
		g.drawImage(image, centerX-5, centerY-3, null);
		openList.clear();
		closedList.clear();
	}
	
	
	private Tile findTile(int x,int y){
		for (int i =4 ;i>-1;i--){
			if(isInBounds((Pacman.centerY/Board.TILE_D)+i*y,(Pacman.centerX/Board.TILE_D)+ i* x)){
				if(!Board.tileArray[(Pacman.centerY/Board.TILE_D)+i*y][(Pacman.centerX/Board.TILE_D)+ i* x].isWall){
					return Board.tileArray[(Pacman.centerY/Board.TILE_D)+i*y][(Pacman.centerX/Board.TILE_D)+ i* x];
				}
			}
		}
		return null;	
	}
	
	public Tile findTargetTile(){
		if(Pacman.direction==Pacman.Direction.RIGHT){
			return this.findTile(1,0);		
		}
		if(Pacman.direction==Pacman.Direction.LEFT){		
			return this.findTile(-1,0);	
		}
		if(Pacman.direction==Pacman.Direction.UP){	
			return this.findTile(0,-1);
		}
				return this.findTile(0,1);
	}
}
