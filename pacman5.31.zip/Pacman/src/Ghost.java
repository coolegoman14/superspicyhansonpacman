import java.awt.Graphics2D;

import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.Timer;

public abstract class Ghost {

	Image image;
	Image frightened;
	// Rectangle clone = new Rectangle();
	static int interval = 0;
	int speed = 12;
	int centerX;
	int centerY;
	int dotLimit;
	static int dotCounter;
	private List<Tile> openList = new ArrayList<Tile>(), closedList = new ArrayList<Tile>();
	private List<Tile> adjacentTiles = new ArrayList<Tile>(), finalPath = new ArrayList<Tile>();
	Tile current, targetTile, startTile;
	Tile[][] tileArray;
	Tile.Direction previousDirection = Tile.Direction.RIGHT;
	static boolean isScared;
	static boolean inScatterMode;
	boolean eaten = false;
	static int secondsOfScare = 10;
	static Timer timer = new Timer(1000, null);
	Random random = new Random();
	private List<Tile> excludedTiles = new ArrayList<Tile>();

	public Ghost() {
		try {
			this.frightened = ImageIO.read(new File("scaredGhost.gif")).getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.tileArray = Board.cloneTile();
		for (int i = 0; i < tileArray.length; i++) {
			for (int x = 0; x < tileArray[i].length; x++) {
				if (tileArray[i][x].isWall) {
					excludedTiles.add(tileArray[i][x]);
				}
			}
		}
	}

	public abstract Tile findTargetTile();

	public void draw(Graphics2D g) {
		if (dotCounter >= dotLimit) {
			findPath();
			move();
		}

		/*
		 * clone.setFrame(centerX, centerY, 5, 5);
		 * clone.setFrameFromCenter(centerX, centerY, centerX, centerY);
		 * g.draw(clone);
		 */
		if (isScared) {
			g.drawImage(frightened, centerX - 12, centerY - 12, null);
		} else {
			g.drawImage(image, centerX - 12, centerY - 12, null);
		}
		openList.clear();
		closedList.clear();

	}

	public static void makeScared() {
		isScared = true;
		scareTimer(secondsOfScare);
	}

	private boolean canMove(Tile.Direction desiredDirection, Tile tile) {
		if (desiredDirection == Tile.Direction.RIGHT) {
			if (tile.direction == Tile.Direction.LEFT) {
				return false;
			}
			if (tileArray[tile.centerY / Board.TILE_D][(tile.centerX / Board.TILE_D) + 1].isWall) {
				return false;
			}
			/*
			 * else
			 * if(Board.tileArray[tile.centerY/Board.TILE_D][tile.centerX/Board.
			 * TILE_D].centerX==centerX &&
			 * Board.tileArray[tile.centerY/Board.TILE_D][(centerX/Board.TILE_D)
			 * +1].isWall){ System.out.println("here"); return false; }
			 */
		}
		if (desiredDirection == Tile.Direction.LEFT) {
			if (tile.direction == Tile.Direction.RIGHT) {
				return false;
			}
			if (tileArray[tile.centerY / Board.TILE_D][(tile.centerX / Board.TILE_D) - 1].isWall) {
				return false;
			}
			/*
			 * else
			 * if(Board.tileArray[tile.centerY/Board.TILE_D][tile.centerX/Board.
			 * TILE_D].centerX==centerX &&
			 * Board.tileArray[tile.centerY/Board.TILE_D][(tile.centerX/Board.
			 * TILE_D)-1].isWall){ return false; }
			 */
		}
		if (desiredDirection == Tile.Direction.UP) {
			if (tile.direction == Tile.Direction.DOWN) {
				return false;
			}
			if (tileArray[(tile.centerY / Board.TILE_D) - 1][tile.centerX / Board.TILE_D].isWall) {
				return false;
			}
			
			/*
			 * else
			 * if(Board.tileArray[tile.centerY/Board.TILE_D][tile.centerX/Board.
			 * TILE_D].centerY==centerY &&
			 * Board.tileArray[(tile.centerY/Board.TILE_D)-1][tile.centerX/Board
			 * .TILE_D].isWall){ return false; }
			 */
		}
		if (desiredDirection == Tile.Direction.DOWN) {
			if (tile.direction == Tile.Direction.UP) {
				return false;

			}
			if (tileArray[(tile.centerY / Board.TILE_D) + 1][tile.centerX / Board.TILE_D].isWall) {
				return false;
			}
			/*
			 * else
			 * if(Board.tileArray[tile.centerY/Board.TILE_D][tile.centerX/Board.
			 * TILE_D].centerY==centerY &&
			 * Board.tileArray[(tile.centerY/Board.TILE_D)+1][tile.centerX/Board
			 * .TILE_D].isWall){ return false; }
			 */
		}

		return true;
	}

	private void findAdjacentTiles(Tile current) {
		adjacentTiles.clear();
		if (canMove(Tile.Direction.RIGHT, current)) {
			tileArray[current.centerY / Board.TILE_D][(current.centerX / Board.TILE_D)
					+ 1].direction = Tile.Direction.RIGHT;
			adjacentTiles.add(tileArray[current.centerY / Board.TILE_D][(current.centerX / Board.TILE_D) + 1]);
		}
		if (canMove(Tile.Direction.LEFT, current)) {
			tileArray[current.centerY / Board.TILE_D][(current.centerX / Board.TILE_D)
					- 1].direction = Tile.Direction.LEFT;
			adjacentTiles.add(tileArray[current.centerY / Board.TILE_D][(current.centerX / Board.TILE_D) - 1]);
		}
		if (canMove(Tile.Direction.UP, current)) {
			tileArray[(current.centerY / Board.TILE_D) - 1][current.centerX
					/ Board.TILE_D].direction = Tile.Direction.UP;
			adjacentTiles.add(tileArray[(current.centerY / Board.TILE_D) - 1][current.centerX / Board.TILE_D]);
		}
		if (canMove(Tile.Direction.DOWN, current)) {
			tileArray[(current.centerY / Board.TILE_D) + 1][current.centerX
					/ Board.TILE_D].direction = Tile.Direction.DOWN;
			adjacentTiles.add(tileArray[(current.centerY / Board.TILE_D) + 1][current.centerX / Board.TILE_D]);
		}
	}

	private void findPath() {
		startTile = tileArray[centerY / Board.TILE_D][centerX / Board.TILE_D];
		startTile.direction = previousDirection;
		System.out.println(startTile.direction);
		finalPath.clear();
		if (isScared) {
			targetTile = targetRandom();
		} else {
			targetTile = findTargetTile();
		}
		finalPath.add(targetTile);
		openList.add(startTile);

		while (!openList.isEmpty()) {
			current = findSmallestNode();
			openList.remove(current);
			closedList.add(current);
			if (closedList.contains(targetTile)) {
				break;
			}
			findAdjacentTiles(current);
			for (Tile tile : adjacentTiles) {
				if (closedList.contains(tile)) {
					continue;
				}
				if (!openList.contains(tile)) {
					tile.parent = current;
					tile.calculateFHG();
					openList.add(tile);
				} else {

				}
			}
		}
		addToFinalPath();
	}

	private Tile findSmallestNode() {
		Tile smallest = openList.get(0);
		for (int i = 0; i < openList.size(); i++) {
			if (openList.get(i).Fscore <= smallest.Fscore) {
				smallest = openList.get(i);
			}
		}
		return smallest;
	}

	private void addToFinalPath() {
		while (targetTile != startTile) {
			if (targetTile.parent != null) {
				targetTile = targetTile.parent;
			} else {
				break;
			}
			finalPath.add(targetTile);
		}
		if (finalPath.size() > 1) {
			previousDirection = finalPath.get(finalPath.size() - 2).direction;
		}
	}

	private void move() {
		if (finalPath.size() > 1) {
			moveTo(finalPath.get(finalPath.size() - 2));
		}
	}

	private void moveTo(Tile tile) {
		if (centerX < tile.centerX) {
			centerX += speed;
		}
		if (centerX > tile.centerX) {
			centerX -= speed;
		}
		if (centerY < tile.centerY) {
			centerY += speed;
		}
		if (centerY > tile.centerY) {
			centerY -= speed;
		}
	}

	public boolean isInBounds(int y, int x) {
		if (x < 0 || x > 27) {
			return false;
		} else if (y < 0 || y > 30) {
			return false;
		}
		return true;
	}

	public static void scareTimer(int duration) {

		timer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				interval++;
				if (interval == duration) {
					isScared = false;
					timer.stop();
				}
			}

		});
		timer.start();
	}

	private Tile targetRandom() {

		int randomX;
		int randomY;
		while (true) {
			randomX = random.nextInt(30);
			randomY = random.nextInt(27);
			if (!excludedTiles.contains(tileArray[randomX][randomY])) {
				return tileArray[randomX][randomY];
			}
		}
	}

	public void deathAnimation() {

	}
}
