
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Blinky extends Ghost {

	public Blinky() {
		try {
			this.image = ImageIO.read(new File("Blinky.png")).getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.initialCenterX= Board.TILE_D * 13 + Board.TILE_D / 2;
		this.initialCenterY= Board.TILE_D * 11 + Board.TILE_D / 2;
		this.centerX =initialCenterX;
		this.centerY =initialCenterY;
		this.dotLimit = 0;
		allGhosts.add(this);

	}

	public Tile findTargetTile() {
		if (inScatterMode && Board.tileArray[centerY / Board.TILE_D][centerX / Board.TILE_D] != Board.tileArray[1][26]) {
			return Board.tileArray[1][26];
		} else if (inScatterMode) {
			return Board.tileArray[2][26];
		}
		return Board.tileArray[Pacman.centerY / Board.TILE_D][Pacman.centerX / Board.TILE_D];
	}

}
