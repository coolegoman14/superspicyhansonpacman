import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.print.attribute.standard.Media;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.AbstractAction;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.Timer;

public class StartPacc {

	private JFrame frame = new JFrame("PAC-MAN");
	private JPanel panel;
	static Timer timer = new Timer(50,null);
	static int lives = 3;
	int waiting = 0;
	Pacman pacman= new Pacman();
	Blinky blinky= new Blinky();
	Pinky pinky= new Pinky();
	static boolean firstKey = true;
	Image life;
	int temp = 0;
	static boolean win = false;
	boolean recall = false;
	Clyde clyde= new Clyde();
	Inky inky= new Inky(blinky);
	Board board= new Board(blinky, pinky, clyde, inky);
	int timesound=0;
	Image victory;
	int time=0;
	static Clip clip;
	Image over;
	boolean gameOver = false;
	boolean rPossible = false;


	public StartPacc() {



		try {
			this.over = ImageIO.read(new File("GameOver.png")).getScaledInstance(300, 300, Image.SCALE_SMOOTH);
			this.life=ImageIO.read(new File("life.png")).getScaledInstance(50, 50,Image.SCALE_SMOOTH);
			this.victory = ImageIO.read(new File("victory.png")).getScaledInstance(1100,180, Image.SCALE_SMOOTH);
			File chomp = new File("chomp.wav");
			clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(chomp));
		} catch (IOException | LineUnavailableException | UnsupportedAudioFileException e) {
			e.printStackTrace();
		}

	}


	public void startGame() {





		panel = new JPanel() {
			@Override
			public void paintComponent(Graphics g) {
				super.paintComponent(g);



				board.drawBoard((Graphics2D) g);
				board.drawGhostPath((Graphics2D) g);
				pacman.draw((Graphics2D) g);
				blinky.draw((Graphics2D) g);
				pinky.draw((Graphics2D) g);
				inky.draw((Graphics2D) g);
				clyde.draw((Graphics2D) g);
				drawLives(g);
				if(win) {
					g.drawImage(victory, 300, 300, null);
					g.setFont(new Font("arial" , Font.BOLD, 25));
					g.drawString("Press 'r' to restart", 700,500 );
					rPossible = true;
				}
				if(gameOver) {
					g.drawImage(over, 200, 200, null);
					g.setFont(new Font("arial" , Font.BOLD, 25));
					g.drawString("Press 'r' to restart", 245,500 );
					rPossible = true;
				}
			}


		};
		makeFrame();

		setUpKeyMappings();


		timer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {

				tick();

			}
		});
		timer.start();
	}


	protected void tick()  {
		if(win) {
			winProtocol();
		}
		if(firstKey) {
			startPlayers();
		}
		if(recall) {
			recallProtocol();
		} else {
			if (pacman.direction!=pacman.userDirection && pacman.canMove(pacman.userDirection)) {
				pacman.direction=pacman.userDirection;
				pacman.changeAngleAttributes(pacman.direction);
			}
			checkCollision();
			pacman.move();
			pacman.doMouthAnimation();
		}
		panel.repaint();
	}

	private void drawLives(Graphics g) {
		int x = 800;
		int y =150;
		for(int i = 0; i < lives; i++) {
			g.drawImage(life, x, y, null);
			x += 50;
		}
	}

	private void checkCollision() {
		for(Ghost g: Board.ghosts) {
			if(pacman.clone.intersects(g.clone) && g.isScared == true) {
				playDeath();
				pacman.coins += 200;
				g.deathAnimation();
				return;
			}
			if(pacman.clone.intersects(g.clone) && g.isScared == false) {
				playEatGhost();
				lives--;
				if(lives == 0) {
					stopPlayers();
					gameOver = true;
				}else {
					recall = true;	
				}

				return;
			}
		}


	}

	public static void playChomp() {
		if(!clip.isActive()) {
			clip.start();
			clip.toString();
		} 
	}




	public void stopChomp() {
		clip.stop();
	}

	private void playEatGhost() {
		stopChomp();
		File chomp = new File("pacman_eatghost.wav");
		try {
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(chomp));

			clip.start();

		} catch (Exception e) {

		}


	}
	private void playDeath() {
		stopChomp();
		// TODO Auto-generated method stub
		File chomp = new File("pacman_death.wav");
		try {
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(chomp));

			clip.start();

		} catch (Exception e) {

		}

	}


	private void setUpKeyMappings() {
		panel.getInputMap().put(KeyStroke.getKeyStroke("LEFT"),"left");
		panel.getInputMap().put(KeyStroke.getKeyStroke("RIGHT"),"right");
		panel.getInputMap().put(KeyStroke.getKeyStroke("UP"),"up");
		panel.getInputMap().put(KeyStroke.getKeyStroke("DOWN"),"down");
		panel.getInputMap().put(KeyStroke.getKeyStroke("R"), "r");

		panel.getActionMap().put("r", new AbstractAction(){
			@Override
			public void actionPerformed(ActionEvent e) {
				if(rPossible) {
					//resetGame();
				}
			}
		});

		panel.getActionMap().put("left",new AbstractAction(){
			@Override
			public void actionPerformed(ActionEvent e) {
				pacman.userDirection=Pacman.Direction.LEFT;

				StartPacc.firstKey = false;
				if(pacman.canMove(Pacman.Direction.LEFT)){
					pacman.direction=Pacman.Direction.LEFT;
					pacman.changeAngleAttributes(Pacman.Direction.LEFT);

				}
			}
		});
		panel.getActionMap().put("right",new AbstractAction(){
			@Override
			public void actionPerformed(ActionEvent e) {

				StartPacc.firstKey = false;
				pacman.userDirection=Pacman.Direction.RIGHT;
				if(pacman.canMove(Pacman.Direction.RIGHT)){
					pacman.direction=Pacman.Direction.RIGHT;
					pacman.changeAngleAttributes(Pacman.Direction.RIGHT);
				}

			}
		});
		panel.getActionMap().put("up",new AbstractAction(){
			@Override
			public void actionPerformed(ActionEvent e) {
				StartPacc.firstKey = false;
				pacman.userDirection=Pacman.Direction.UP;
				if(pacman.canMove(Pacman.Direction.UP)){
					pacman.direction=Pacman.Direction.UP;
					pacman.changeAngleAttributes(Pacman.Direction.UP);
				}
			}
		});
		panel.getActionMap().put("down",new AbstractAction(){
			@Override
			public void actionPerformed(ActionEvent e) {
				StartPacc.firstKey = false;
				pacman.userDirection=Pacman.Direction.DOWN;
				if(pacman.canMove(Pacman.Direction.DOWN)){
					pacman.direction=Pacman.Direction.DOWN;
					pacman.changeAngleAttributes(Pacman.Direction.DOWN);
				}
			}
		});
		panel.requestFocusInWindow();
	}

	private void makeFrame(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(panel);
		panel.setPreferredSize(new Dimension(1500,800));
		frame.pack();
		frame.setVisible(true);
		panel.setBackground(Color.black);
		this.setUpKeyMappings();
	}

	public void recallProtocol() {

		System.out.println("pacman radius " + pacman.radius);
		if(pacman.radius > 1) {
			pacman.radius--;
			return;
		}
		else {
			for(Ghost a : Board.ghosts) {
				a.putInCamp();
			}
			pacman.radius = 35;
			pacman.putBack();
			stopPlayers();
			recall = false;
			firstKey = true;
			win = false;
		}	
	}
	private void stopPlayers() {
		pacman.speed = 0;
		for(Ghost a : Board.ghosts) {
			a.speed = 0;
		}
	}

	public void startPlayers() {
		pacman.speed = 6;
		for(Ghost a : Board.ghosts) {
			a.speed = 6;
		}
	}
	public void winProtocol() {
		stopPlayers();
		board.makeTileArray();
		for(Ghost a : Board.ghosts) {
			a.putInCamp();
		}
		pacman.putBack();
		firstKey = true;
		win = false;
	}

}



